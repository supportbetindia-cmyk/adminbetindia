# BetIndia Smart Link Manager

Campaign attribution platform: publisher banner → smart link → approved
destination → lead → registration → FTD.

Built against the specifications in `docs/`. See `CLAUDE.md` for architecture,
the rules taken from those specifications, and build status.

## Requirements

- Node 20+
- PostgreSQL 16+

## Setup

```bash
npm install
cp .env.example .env      # set DATABASE_URL and IP_HASH_SALT
npm run db:migrate
npm run db:seed
npm run dev
```

Then open http://localhost:3000/c/demo-web-sep01 — it redirects to the seeded
destination with a click ID attached, and writes a row to `click_events`.

## Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Development server on :3000 |
| `npm run db:generate` | Regenerate SQL migrations after schema changes |
| `npm run db:migrate` | Apply migrations |
| `npm run db:seed` | Seed demo publisher, campaign and links |
| `npm test` | Acceptance tests (requires a live database) |
| `npm run typecheck` | TypeScript check |

## Status

Feature 1 (foundation + redirect engine) is complete and tested. Remaining
features and their blockers are listed in `CLAUDE.md`.
