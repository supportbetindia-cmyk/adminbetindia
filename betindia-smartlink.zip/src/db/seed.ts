/**
 * Development seed.
 *
 * Creates one publisher, campaign, creative and two smart links — one website
 * destination and one WhatsApp destination — so the redirect engine can be
 * exercised end to end.
 *
 * Publisher names here are placeholders for local testing only. Per PRD §9,
 * illustrative data must never be presented as actual campaign results.
 */

import 'dotenv/config';
import { eq } from 'drizzle-orm';
import { db, pool } from './index';
import {
  adminUsers, campaigns, creatives, destinations, destinationVersions, publishers, smartLinks,
} from './schema';

async function main() {
  const [admin] = await db
    .insert(adminUsers)
    .values({ email: 'admin@betindia.bet', role: 'super_admin' })
    .onConflictDoNothing()
    .returning();

  const adminId =
    admin?.id ??
    (await db.select().from(adminUsers).where(eq(adminUsers.email, 'admin@betindia.bet')))[0].id;

  const [publisher] = await db
    .insert(publishers)
    .values({ name: 'Demo Publisher', status: 'active', externalReference: 'DEMO-001' })
    .returning();

  const [campaign] = await db
    .insert(campaigns)
    .values({
      publisherId: publisher.id,
      name: 'Demo Campaign — Sept',
      status: 'active',
      startsAt: new Date(Date.now() - 86_400_000),
      endsAt: new Date(Date.now() + 30 * 86_400_000),
      currency: 'INR',
      attributionWindowDays: 30,
    })
    .returning();

  const [creative] = await db
    .insert(creatives)
    .values({
      campaignId: campaign.id,
      name: 'Banner 300x250 v1',
      format: '300x250',
      approvalStatus: 'approved',
    })
    .returning();

  // Approved destinations only — an unapproved row must never be redirected to.
  const [websiteDest] = await db
    .insert(destinations)
    .values({
      type: 'website',
      url: 'https://www.betindia.bet/promo/welcome',
      approvalStatus: 'approved',
      approvalReference: 'DEMO-APPROVAL-1',
      approvedBy: adminId,
      approvedAt: new Date(),
    })
    .returning();

  const [whatsappDest] = await db
    .insert(destinations)
    .values({
      type: 'whatsapp',
      url: 'https://wa.me/919000000000?text=Hi',
      approvalStatus: 'approved',
      approvalReference: 'DEMO-APPROVAL-2',
      approvedBy: adminId,
      approvedAt: new Date(),
    })
    .returning();

  for (const [slug, dest] of [
    ['demo-web-sep01', websiteDest],
    ['demo-wa-sep01', whatsappDest],
  ] as const) {
    const [link] = await db
      .insert(smartLinks)
      .values({
        campaignId: campaign.id,
        creativeId: creative.id,
        slug,
        destinationType: dest.type,
        activeDestinationId: dest.id,
        activeDestinationVersion: 1,
        status: 'active',
        createdBy: adminId,
      })
      .returning();

    await db.insert(destinationVersions).values({
      smartLinkId: link.id,
      destinationId: dest.id,
      version: 1,
      changedBy: adminId,
      approvalReference: dest.approvalReference,
    });

    console.log(`seeded /c/${slug} -> ${dest.url}`);
  }

  await pool.end();
}

main().catch(async (err) => {
  console.error(err);
  await pool.end();
  process.exit(1);
});
