export default function Home() {
  return (
    <main style={{ fontFamily: 'system-ui', padding: 40 }}>
      <h1>Smart Link Manager</h1>
      <p>Admin dashboard is built in a later feature. The redirect endpoint is live at /c/&#123;slug&#125;.</p>
    </main>
  );
}
