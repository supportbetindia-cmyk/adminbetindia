export const metadata = {
  title: 'BetIndia Smart Link Manager',
  description: 'Campaign attribution and link management',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
